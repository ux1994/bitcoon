function FooterLinks(){
    return(
        <section className="copyright">
        <div className="container">
            <div className="row">
                <div className="col-lg-7 m-auto">
                    <ul className="footer_link">
                        <li><a href="/">Medium</a></li>
                        <li><a href="/">Etherscan</a></li>
                        <li><a href="/">CoinMarketCap</a></li>
                        <li><a href="/">CoinGecko</a></li>
                    </ul>

                </div>
            </div>
        </div>
    </section>


    )
}

export default FooterLinks